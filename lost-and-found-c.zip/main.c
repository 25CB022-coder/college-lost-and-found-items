/*
 * Lost & Found Management System
 * ------------------------------------------------------------
 * DSA mini project in C.
 *
 * Data structures used:
 *   - Singly linked list  : one list for LOST items, one for FOUND items
 *   - Dynamic memory      : malloc/free for every node
 *   - File persistence    : items are saved to / loaded from a text file
 *
 * Algorithms used:
 *   - Linear search with case-insensitive substring matching
 *   - Scoring-based matching between lost and found reports
 *   - Insertion sort (on a small array) to rank match results
 *
 * Build : gcc -Wall -Wextra -o lostfound main.c
 * Run   : ./lostfound        (Windows: lostfound.exe)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define NAME_LEN 50
#define CAT_LEN 30
#define DESC_LEN 100
#define LOC_LEN 50
#define DATE_LEN 12
#define CONTACT_LEN 50
#define DATA_FILE "lostfound_data.txt"
#define MATCH_THRESHOLD 50

typedef enum { LOST = 0, FOUND = 1 } ItemType;

typedef struct Item {
    int id;
    ItemType type;
    char name[NAME_LEN];
    char category[CAT_LEN];
    char description[DESC_LEN];
    char location[LOC_LEN];
    char date[DATE_LEN];
    char contact[CONTACT_LEN];
    struct Item *next;
} Item;

static Item *lostHead = NULL;
static Item *foundHead = NULL;
static int nextId = 1;

/* ---------------------------- helpers ---------------------------- */

static void readLine(const char *prompt, char *buf, size_t size, int allowEmpty) {
    for (;;) {
        printf("%s", prompt);
        if (!fgets(buf, (int)size, stdin)) {
            buf[0] = '\0';
            return;
        }
        size_t len = strlen(buf);
        if (len > 0 && buf[len - 1] == '\n') {
            buf[len - 1] = '\0';
        } else {
            int c; /* line was longer than buffer: discard the rest */
            while ((c = getchar()) != '\n' && c != EOF) {}
        }
        for (size_t i = 0; buf[i]; i++)
            if (buf[i] == '|') buf[i] = '-'; /* '|' is our file delimiter */
        if (buf[0] != '\0') return;
        if (allowEmpty) {
            strcpy(buf, "N/A");
            return;
        }
        printf("  This field cannot be empty.\n");
    }
}

static int readInt(const char *prompt) {
    char buf[32];
    printf("%s", prompt);
    if (!fgets(buf, sizeof buf, stdin)) return -1;
    return atoi(buf);
}

static int ciEqual(const char *a, const char *b) {
    while (*a && *b) {
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return 0;
        a++;
        b++;
    }
    return *a == *b;
}

/* case-insensitive "does hay contain needle?" */
static int ciContains(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    if (n == 0) return 1;
    for (; *hay; hay++) {
        size_t i = 0;
        while (i < n && hay[i] &&
               tolower((unsigned char)hay[i]) == tolower((unsigned char)needle[i]))
            i++;
        if (i == n) return 1;
    }
    return 0;
}

static const char *typeName(ItemType t) { return t == LOST ? "LOST" : "FOUND"; }

/* ------------------------ linked list ops ------------------------ */

static void appendItem(Item **head, Item *node) {
    node->next = NULL;
    if (!*head) {
        *head = node;
        return;
    }
    Item *cur = *head;
    while (cur->next) cur = cur->next;
    cur->next = node;
}

static Item *findById(Item *head, int id) {
    for (; head; head = head->next)
        if (head->id == id) return head;
    return NULL;
}

static int removeById(Item **head, int id) {
    Item *prev = NULL, *cur = *head;
    while (cur) {
        if (cur->id == id) {
            if (prev) prev->next = cur->next;
            else *head = cur->next;
            free(cur);
            return 1;
        }
        prev = cur;
        cur = cur->next;
    }
    return 0;
}

static void freeList(Item **head) {
    Item *cur = *head;
    while (cur) {
        Item *tmp = cur->next;
        free(cur);
        cur = tmp;
    }
    *head = NULL;
}

static int countItems(Item *head) {
    int n = 0;
    for (; head; head = head->next) n++;
    return n;
}

/* --------------------------- file I/O ---------------------------- */

static void saveData(void) {
    FILE *fp = fopen(DATA_FILE, "w");
    if (!fp) {
        printf("Warning: could not save data to %s\n", DATA_FILE);
        return;
    }
    Item *lists[2] = {lostHead, foundHead};
    for (int i = 0; i < 2; i++) {
        for (Item *p = lists[i]; p; p = p->next)
            fprintf(fp, "%d|%d|%s|%s|%s|%s|%s|%s\n", (int)p->type, p->id, p->name,
                    p->category, p->description, p->location, p->date, p->contact);
    }
    fclose(fp);
}

static void loadData(void) {
    FILE *fp = fopen(DATA_FILE, "r");
    if (!fp) return; /* first run: no file yet */
    char line[512];
    while (fgets(line, sizeof line, fp)) {
        Item *it = (Item *)calloc(1, sizeof(Item));
        if (!it) break;
        int type;
        int n = sscanf(line, "%d|%d|%49[^|]|%29[^|]|%99[^|]|%49[^|]|%11[^|]|%49[^\n]",
                       &type, &it->id, it->name, it->category, it->description,
                       it->location, it->date, it->contact);
        if (n != 8 || (type != 0 && type != 1)) {
            free(it);
            continue;
        }
        it->type = (ItemType)type;
        if (it->id >= nextId) nextId = it->id + 1;
        appendItem(it->type == LOST ? &lostHead : &foundHead, it);
    }
    fclose(fp);
}

/* ------------------------- core features ------------------------- */

static void reportItem(ItemType type) {
    Item *it = (Item *)calloc(1, sizeof(Item));
    if (!it) {
        printf("Out of memory!\n");
        return;
    }
    it->id = nextId++;
    it->type = type;
    printf("\n--- Report a %s item ---\n", type == LOST ? "LOST" : "FOUND");
    readLine("Item name (e.g. Calculator): ", it->name, sizeof it->name, 0);
    readLine("Category (ID card / Book / Calculator / Bag / Other): ", it->category,
             sizeof it->category, 0);
    readLine("Description (colour, brand, marks) [optional]: ", it->description,
             sizeof it->description, 1);
    readLine(type == LOST ? "Place where it was lost: " : "Place where it was found: ",
             it->location, sizeof it->location, 0);
    readLine("Date (DD-MM-YYYY): ", it->date, sizeof it->date, 0);
    readLine(type == LOST ? "Your contact (phone/email): "
                          : "Contact / where item is kept: ",
             it->contact, sizeof it->contact, 0);

    appendItem(type == LOST ? &lostHead : &foundHead, it);
    saveData();
    printf("\nSaved! Your %s report ID is %d.\n", typeName(type), it->id);
}

static void printItem(const Item *p) {
    printf("  [%s #%d] %s | Category: %s\n", typeName(p->type), p->id, p->name,
           p->category);
    printf("      Details : %s\n", p->description);
    printf("      Place   : %s    Date: %s\n", p->location, p->date);
    printf("      Contact : %s\n", p->contact);
}

static void displayList(Item *head, const char *title) {
    printf("\n===== %s (%d) =====\n", title, countItems(head));
    if (!head) {
        printf("  (none)\n");
        return;
    }
    for (Item *p = head; p; p = p->next) printItem(p);
}

static void displayAll(void) {
    displayList(lostHead, "LOST ITEMS");
    displayList(foundHead, "FOUND ITEMS");
}

static int searchList(Item *head, const char *key) {
    int hits = 0;
    for (Item *p = head; p; p = p->next) {
        if (ciContains(p->name, key) || ciContains(p->category, key) ||
            ciContains(p->description, key)) {
            printItem(p);
            hits++;
        }
    }
    return hits;
}

static void searchItems(void) {
    char key[NAME_LEN];
    printf("\n--- Search by item name or category ---\n");
    readLine("Enter keyword: ", key, sizeof key, 0);
    printf("\nResults in LOST reports:\n");
    int a = searchList(lostHead, key);
    if (!a) printf("  (no match)\n");
    printf("\nResults in FOUND reports:\n");
    int b = searchList(foundHead, key);
    if (!b) printf("  (no match)\n");
    printf("\nTotal: %d result(s).\n", a + b);
}

/* ------------------------ matching engine ------------------------ */

/* number of words (>= 3 letters) of 'a' that also appear in 'b', capped */
static int sharedWords(const char *a, const char *b) {
    char copy[NAME_LEN + DESC_LEN + 2];
    snprintf(copy, sizeof copy, "%s", a);
    int count = 0;
    for (char *w = strtok(copy, " ,.;:-/"); w; w = strtok(NULL, " ,.;:-/"))
        if (strlen(w) >= 3 && ciContains(b, w)) count++;
    return count;
}

static int matchScore(const Item *lost, const Item *found) {
    int score = 0;
    if (ciEqual(lost->category, found->category)) score += 40;
    if (ciEqual(lost->name, found->name)) score += 40;
    else if (ciContains(lost->name, found->name) || ciContains(found->name, lost->name))
        score += 25;

    char la[NAME_LEN + DESC_LEN + 2], fb[NAME_LEN + DESC_LEN + 2];
    snprintf(la, sizeof la, "%s %s", lost->name, lost->description);
    snprintf(fb, sizeof fb, "%s %s", found->name, found->description);
    int words = sharedWords(la, fb) * 5;
    score += words > 20 ? 20 : words;

    if (ciEqual(lost->location, found->location)) score += 10;
    else if (ciContains(lost->location, found->location) ||
             ciContains(found->location, lost->location))
        score += 5;
    return score > 100 ? 100 : score;
}

typedef struct {
    Item *lost;
    Item *found;
    int score;
} Match;

static void matchItems(void) {
    printf("\n--- Matching LOST reports with FOUND reports ---\n");
    int total = countItems(lostHead) * countItems(foundHead);
    if (total == 0) {
        printf("You need at least one lost and one found report to match.\n");
        return;
    }
    Match *list = (Match *)malloc(sizeof(Match) * (size_t)total);
    if (!list) {
        printf("Out of memory!\n");
        return;
    }
    int n = 0;
    for (Item *l = lostHead; l; l = l->next)
        for (Item *f = foundHead; f; f = f->next) {
            int s = matchScore(l, f);
            if (s >= MATCH_THRESHOLD) {
                list[n].lost = l;
                list[n].found = f;
                list[n].score = s;
                n++;
            }
        }

    /* insertion sort: best score first */
    for (int i = 1; i < n; i++) {
        Match key = list[i];
        int j = i - 1;
        while (j >= 0 && list[j].score < key.score) {
            list[j + 1] = list[j];
            j--;
        }
        list[j + 1] = key;
    }

    if (n == 0) {
        printf("No likely matches found yet.\n");
    } else {
        for (int i = 0; i < n; i++) {
            printf("\nMatch %d  (confidence %d%%)\n", i + 1, list[i].score);
            printItem(list[i].lost);
            printItem(list[i].found);
        }
        printf("\n%d possible match(es). Contact the finder using the details above.\n", n);
    }
    free(list);
}

static void resolvePair(void) {
    printf("\n--- Mark an item as returned (removes both reports) ---\n");
    int lid = readInt("Lost report ID: ");
    int fid = readInt("Found report ID: ");
    if (!findById(lostHead, lid) || !findById(foundHead, fid)) {
        printf("Invalid IDs: need one existing LOST id and one existing FOUND id.\n");
        return;
    }
    removeById(&lostHead, lid);
    removeById(&foundHead, fid);
    saveData();
    printf("Done. Reports %d and %d have been closed.\n", lid, fid);
}

/* ------------------------------ main ----------------------------- */

static void printMenu(void) {
    printf("\n=========================================\n");
    printf("   LOST & FOUND - Student Belongings\n");
    printf("=========================================\n");
    printf(" 1. Report a lost item\n");
    printf(" 2. Report a found item\n");
    printf(" 3. Search by item name or category\n");
    printf(" 4. Display all reported items\n");
    printf(" 5. Match lost items with found items\n");
    printf(" 6. Mark item as returned (close reports)\n");
    printf(" 0. Exit\n");
}

int main(void) {
    loadData();
    for (;;) {
        printMenu();
        int choice = readInt("Enter choice: ");
        switch (choice) {
            case 1: reportItem(LOST); break;
            case 2: reportItem(FOUND); break;
            case 3: searchItems(); break;
            case 4: displayAll(); break;
            case 5: matchItems(); break;
            case 6: resolvePair(); break;
            case 0:
                saveData();
                freeList(&lostHead);
                freeList(&foundHead);
                printf("Goodbye!\n");
                return 0;
            default: printf("Invalid choice, try again.\n");
        }
    }
}
