# Lost & Found Management System (C)

A console-based DSA mini project that helps students report, search and match lost and found belongings such as ID cards, books and calculators.

## Features

1. Report a lost item
2. Report a found item
3. Search by item name or category (case-insensitive, partial match)
4. Display all reported items
5. Match lost-item reports with found-item reports (ranked by confidence %)
6. Mark an item as returned (closes both reports)

Data is saved automatically to `lostfound_data.txt`, so reports survive between runs.

## Data Structures & Algorithms

| Concept | Where it is used |
|---|---|
| Singly linked list | Separate lists for lost and found items (insert at tail, delete by ID, traverse) |
| Dynamic memory (`malloc`/`free`) | Every report is a heap-allocated node, freed on exit |
| Linear search | Keyword search over name, category and description |
| Scoring / matching | Category, name, shared keywords and location produce a 0-100 score |
| Insertion sort | Ranks the matches, best first |
| File I/O | Saves and loads the lists using a `|`-delimited text file |

### Matching score

| Rule | Points |
|---|---|
| Same category | +40 |
| Same name / name contains the other | +40 / +25 |
| Shared keywords in name + description | +5 each (max 20) |
| Same location / partial location | +10 / +5 |

Pairs scoring 50 or more are shown as possible matches.

## How to run

### Option 1: VS Code terminal (any OS with gcc)

```bash
gcc -Wall -Wextra -o lostfound main.c
./lostfound          # on Windows: .\lostfound.exe
```

### Option 2: Makefile

```bash
make
make run
```

### Option 3: VS Code build task

Press `Ctrl+Shift+B`, then run `./lostfound` in the terminal.

> Windows: install MinGW-w64 or MSYS2 so that `gcc` is available. On macOS run `xcode-select --install`. On Ubuntu/Debian run `sudo apt install build-essential`.

## Sample session

```
Enter choice: 1        (report lost: Calculator, category Calculator, place Library)
Enter choice: 2        (report found: Casio Calculator, category Calculator, place Library)
Enter choice: 5        -> Match 1 (confidence 85%)
```

## Project structure

```
.
├── main.c
├── Makefile
├── README.md
├── .gitignore
└── .vscode/
    └── tasks.json
```

## Possible improvements

- Replace the linked list search with a hash table for faster lookups
- Add admin login and item expiry
- Add a GUI or web front end
